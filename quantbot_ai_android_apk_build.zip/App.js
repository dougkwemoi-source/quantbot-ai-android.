import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable,
  RefreshControl, SafeAreaView, ScrollView, StatusBar, StyleSheet,
  Text, TextInput, View
} from "react-native";
import Svg, { Defs, LinearGradient, Stop, Path, Line, Circle } from "react-native-svg";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";

// IMPORTANT: Replace this with your computer's LAN IP when testing on a real phone.
// Example: http://192.168.1.25:8000. Android emulator uses http://10.0.2.2:8000.
const API_BASE = "http://192.168.1.25:8000";

const DEMO_MARKETS = [
  { symbol: "BTC", name: "Bitcoin", price: 67420.5, change24h: 2.31 },
  { symbol: "ETH", name: "Ethereum", price: 3521.8, change24h: 1.18 },
  { symbol: "SOL", name: "Solana", price: 158.42, change24h: -0.72 },
];
const STARTING = 10000;
const money = n => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(Number(n || 0));
const price = n => "$" + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}
function SectionTitle({ eyebrow, title, right }) {
  return <View style={styles.sectionHead}><View><Text style={styles.eyebrow}>{eyebrow}</Text><Text style={styles.sectionTitle}>{title}</Text></View>{right}</View>;
}
function Pill({ children, tone = "green" }) {
  return <View style={[styles.pill, tone === "red" && styles.pillRed, tone === "amber" && styles.pillAmber]}><Text style={[styles.pillText, tone === "red" && styles.redText, tone === "amber" && styles.amberText]}>{children}</Text></View>;
}
function Coin({ symbol }) {
  const style = symbol === "BTC" ? styles.btc : symbol === "ETH" ? styles.eth : styles.sol;
  return <View style={[styles.coin, style]}><Text style={styles.coinText}>{symbol === "BTC" ? "₿" : symbol === "ETH" ? "◆" : "S"}</Text></View>;
}
function MiniChart({ seed = 1, color = "#35d6b0" }) {
  const points = useMemo(() => Array.from({ length: 28 }, (_, i) => {
    const y = 52 + Math.sin(i * .58 + seed) * 15 + Math.cos(i * 1.13 + seed) * 8 - i * .27;
    return [i * 11, Math.max(8, Math.min(83, y))];
  }), [seed]);
  const path = points.map((p, i) => `${i ? "L" : "M"} ${p[0]} ${p[1]}`).join(" ");
  return <Svg width="100%" height="90" viewBox="0 0 300 90" preserveAspectRatio="none">
    <Defs><LinearGradient id={`fill${seed}`} x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor={color} stopOpacity=".25"/><Stop offset="1" stopColor={color} stopOpacity="0"/></LinearGradient></Defs>
    {[22, 45, 68].map(y => <Line key={y} x1="0" y1={y} x2="300" y2={y} stroke="#202a38" strokeDasharray="3 5"/>)}
    <Path d={`${path} L 297 90 L 0 90 Z`} fill={`url(#fill${seed})`}/>
    <Path d={path} stroke={color} strokeWidth="2.2" fill="none"/>
    <Circle cx={points[points.length - 1][0]} cy={points[points.length - 1][1]} r="3.5" fill={color}/>
  </Svg>;
}

export default function App() {
  const [tab, setTab] = useState("Home");
  const [markets, setMarkets] = useState(DEMO_MARKETS);
  const [portfolio, setPortfolio] = useState({
    cash: STARTING, startingCash: STARTING, holdings: { BTC: 0, ETH: 0, SOL: 0 },
    positions: { BTC: 0, ETH: 0, SOL: 0 }, equity: STARTING, pnl: 0, pnlPercent: 0
  });
  const [trades, setTrades] = useState([]);
  const [selected, setSelected] = useState("BTC");
  const [side, setSide] = useState("buy");
  const [quantity, setQuantity] = useState("0.01");
  const [apiOnline, setApiOnline] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const active = markets.find(m => m.symbol === selected) || markets[0];
  const positionValue = portfolio.equity - portfolio.cash;

  const load = useCallback(async () => {
    try {
      const [mr, pr, tr] = await Promise.all([
        fetch(`${API_BASE}/api/markets`), fetch(`${API_BASE}/api/portfolio`), fetch(`${API_BASE}/api/trades`)
      ]);
      if (!mr.ok || !pr.ok || !tr.ok) throw new Error("API error");
      setMarkets(await mr.json()); setPortfolio(await pr.json()); setTrades(await tr.json()); setApiOnline(true);
    } catch {
      setApiOnline(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function refresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function placeTrade() {
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty <= 0) {
      setNotice("Enter a quantity greater than zero.");
      return;
    }
    if (!apiOnline) {
      setNotice("API offline. Set API_BASE in App.js and start the backend.");
      return;
    }
    setBusy(true); setNotice("");
    try {
      const response = await fetch(`${API_BASE}/api/trade`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: selected, side, quantity: qty })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Trade failed.");
      setNotice(`${side === "buy" ? "Bought" : "Sold"} ${qty} ${selected} using virtual funds.`);
      await load();
    } catch (e) {
      setNotice(e.message || "Trade failed.");
    } finally { setBusy(false); }
  }

  function navigate(next) {
    setTab(next);
    setNotice("");
  }

  const header = <View style={styles.topHeader}>
    <View style={styles.brandRow}>
      <View style={styles.brandIcon}><Text style={styles.brandGlyph}>Q</Text></View>
      <View><Text style={styles.brand}>QUANT<Text style={styles.brandAccent}>BOT</Text></Text><Text style={styles.brandSub}>AI TRADING LAB</Text></View>
    </View>
    <Pill tone={apiOnline ? "green" : "amber"}>{apiOnline ? "API ONLINE" : "DEMO MODE"}</Pill>
  </View>;

  return <SafeAreaView style={styles.safe}>
    <ExpoStatusBar style="light"/>
    <StatusBar barStyle="light-content" backgroundColor="#080b12"/>
    {header}
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor="#35d6b0"/>}
        keyboardShouldPersistTaps="handled"
      >
        {tab === "Home" && <>
          <View style={styles.welcome}>
            <Text style={styles.eyebrow}>QUANTITATIVE ANALYSIS TERMINAL</Text>
            <Text style={styles.pageTitle}>Trading overview</Text>
            <Text style={styles.subtitle}>Your virtual crypto trading account.</Text>
          </View>
          <Card style={styles.equityCard}>
            <View style={styles.equityTop}><Text style={styles.mutedLabel}>TOTAL ACCOUNT EQUITY</Text><View style={styles.equityIcon}><Text>◈</Text></View></View>
            <Text style={styles.equityValue}>{money(portfolio.equity)}</Text>
            <View style={styles.equityBottom}><Text style={portfolio.pnl >= 0 ? styles.greenText : styles.redText}>{portfolio.pnl >= 0 ? "+" : ""}{money(portfolio.pnl)} ({portfolio.pnlPercent >= 0 ? "+" : ""}{portfolio.pnlPercent}%)</Text><Text style={styles.dimText}>since start</Text></View>
            <View style={styles.equityChart}><MiniChart seed={3}/></View>
            <Text style={styles.chartCaption}>Illustrative chart, not historical market data</Text>
          </Card>
          <View style={styles.statGrid}>
            <Card style={styles.smallStat}><Text style={styles.mutedLabel}>VIRTUAL CASH</Text><Text style={styles.statValue}>{money(portfolio.cash)}</Text><Text style={styles.dimText}>Available funds</Text></Card>
            <Card style={styles.smallStat}><Text style={styles.mutedLabel}>POSITION VALUE</Text><Text style={styles.statValue}>{money(positionValue)}</Text><Text style={styles.dimText}>Current holdings</Text></Card>
          </View>
          <Card>
            <SectionTitle eyebrow="MARKET WATCH" title="Crypto markets" right={<Text style={styles.dimText}>Demo quotes</Text>}/>
            {markets.map((m, i) => <Pressable key={m.symbol} onPress={() => { setSelected(m.symbol); setTab("Trade"); }} style={styles.marketRow}>
              <Coin symbol={m.symbol}/><View style={styles.marketInfo}><Text style={styles.marketName}>{m.name}</Text><Text style={styles.dimText}>{m.symbol}/USD</Text></View>
              <View style={styles.marketRight}><Text style={styles.marketPrice}>{price(m.price)}</Text><Text style={m.change24h >= 0 ? styles.greenText : styles.redText}>{m.change24h > 0 ? "+" : ""}{m.change24h}%</Text></View>
              <View style={{ width: 58, marginLeft: 8 }}><MiniChart seed={i + 2} color={m.change24h >= 0 ? "#35d6b0" : "#f07887"}/></View>
            </Pressable>)}
          </Card>
          <Card>
            <SectionTitle eyebrow="MODEL LAB" title="AI signal status" right={<Pill tone="amber">NOT TRAINED</Pill>}/>
            <View style={styles.aiRow}><View style={styles.aiIcon}><Text style={styles.aiGlyph}>⌘</Text></View><View style={{ flex: 1 }}><Text style={styles.marketName}>Machine-learning model</Text><Text style={styles.aiDescription}>Historical data and validation are needed before this app produces predictions.</Text></View></View>
            <View style={styles.signalRow}><Text style={styles.dimText}>Current signal</Text><Pill tone="amber">WAIT</Pill></View>
            <View style={styles.signalRow}><Text style={styles.dimText}>Confidence</Text><Text style={styles.mutedLabel}>Unavailable</Text></View>
          </Card>
        </>}

        {tab === "Trade" && <>
          <View style={styles.welcome}><Text style={styles.eyebrow}>SIMULATED EXECUTION</Text><Text style={styles.pageTitle}>Paper trading</Text><Text style={styles.subtitle}>No real orders are sent.</Text></View>
          <Card>
            <View style={styles.toggleRow}><Pressable onPress={() => setSide("buy")} style={[styles.toggleButton, side === "buy" && styles.buySelected]}><Text style={[styles.toggleText, side === "buy" && styles.buyText]}>BUY / LONG</Text></Pressable><Pressable onPress={() => setSide("sell")} style={[styles.toggleButton, side === "sell" && styles.sellSelected]}><Text style={[styles.toggleText, side === "sell" && styles.sellText]}>SELL</Text></Pressable></View>
            <Text style={styles.fieldLabel}>Choose asset</Text>
            <View style={styles.assetChoices}>{markets.map(m => <Pressable key={m.symbol} onPress={() => setSelected(m.symbol)} style={[styles.assetChoice, selected === m.symbol && styles.assetChoiceSelected]}><Coin symbol={m.symbol}/><Text style={styles.assetChoiceText}>{m.symbol}</Text></Pressable>)}</View>
            <View style={styles.quoteBox}><Text style={styles.dimText}>Demo market price</Text><Text style={styles.quoteValue}>{price(active.price)}</Text><Text style={styles.dimText}>{active.name} · {active.symbol}/USD</Text></View>
            <Text style={styles.fieldLabel}>Quantity ({selected})</Text>
            <TextInput value={quantity} onChangeText={setQuantity} keyboardType="decimal-pad" placeholder="0.01" placeholderTextColor="#647287" style={styles.input}/>
            <View style={styles.orderLine}><Text style={styles.dimText}>Order value</Text><Text style={styles.orderValue}>{money((Number(quantity) || 0) * active.price)}</Text></View>
            <View style={styles.orderLine}><Text style={styles.dimText}>Simulated fee (0.1%)</Text><Text style={styles.orderValue}>{money((Number(quantity) || 0) * active.price * .001)}</Text></View>
            <Pressable disabled={busy} onPress={placeTrade} style={[styles.primaryButton, side === "sell" && styles.sellPrimary, busy && { opacity: .6 }]}>{busy ? <ActivityIndicator color="#071711"/> : <Text style={styles.primaryButtonText}>{side === "buy" ? "Buy" : "Sell"} {selected} with virtual funds</Text>}</Pressable>
            {!!notice && <Text style={styles.notice}>{notice}</Text>}
            <Text style={styles.disclaimer}>✓  Paper trading only. No real cryptocurrency is purchased.</Text>
          </Card>
        </>}

        {tab === "Portfolio" && <>
          <View style={styles.welcome}><Text style={styles.eyebrow}>ACCOUNT BREAKDOWN</Text><Text style={styles.pageTitle}>Your portfolio</Text><Text style={styles.subtitle}>Virtual balance and open positions.</Text></View>
          <Card><Text style={styles.mutedLabel}>TOTAL EQUITY</Text><Text style={styles.equityValue}>{money(portfolio.equity)}</Text><Text style={portfolio.pnl >= 0 ? styles.greenText : styles.redText}>{portfolio.pnl >= 0 ? "+" : ""}{money(portfolio.pnl)} overall P&L</Text><View style={styles.separator}/><View style={styles.orderLine}><Text style={styles.dimText}>Available cash</Text><Text style={styles.orderValue}>{money(portfolio.cash)}</Text></View><View style={styles.orderLine}><Text style={styles.dimText}>Holdings value</Text><Text style={styles.orderValue}>{money(positionValue)}</Text></View></Card>
          <Card><SectionTitle eyebrow="OPEN POSITIONS" title="Assets held"/></Card>
          <Card>{markets.map(m => { const qty = portfolio.positions?.[m.symbol] || 0; return <View key={m.symbol} style={styles.marketRow}><Coin symbol={m.symbol}/><View style={styles.marketInfo}><Text style={styles.marketName}>{m.name}</Text><Text style={styles.dimText}>{qty.toFixed(6)} {m.symbol}</Text></View><View style={styles.marketRight}><Text style={styles.marketPrice}>{money(qty * m.price)}</Text><Text style={styles.dimText}>Market value</Text></View></View>; })}</Card>
        </>}

        {tab === "History" && <>
          <View style={styles.welcome}><Text style={styles.eyebrow}>ACTIVITY LOG</Text><Text style={styles.pageTitle}>Trade history</Text><Text style={styles.subtitle}>Your recent simulated orders.</Text></View>
          {trades.length === 0 ? <Card style={styles.empty}><Text style={styles.emptyIcon}>◷</Text><Text style={styles.marketName}>No trades yet</Text><Text style={styles.aiDescription}>Place a paper trade to see it recorded here.</Text><Pressable style={styles.primaryButton} onPress={() => navigate("Trade")}><Text style={styles.primaryButtonText}>Go to paper trading</Text></Pressable></Card> :
            trades.map(t => <Card key={t.id} style={styles.tradeHistoryCard}><View style={styles.historyTop}><Coin symbol={t.symbol}/><View style={styles.marketInfo}><Text style={styles.marketName}>{t.symbol}/USD</Text><Text style={styles.dimText}>{new Date(t.time).toLocaleString()}</Text></View><Pill tone={t.side === "BUY" ? "green" : "red"}>{t.side}</Pill></View><View style={styles.orderLine}><Text style={styles.dimText}>Quantity</Text><Text style={styles.orderValue}>{Number(t.quantity).toFixed(6)}</Text></View><View style={styles.orderLine}><Text style={styles.dimText}>Execution price</Text><Text style={styles.orderValue}>{price(t.price)}</Text></View><View style={styles.orderLine}><Text style={styles.dimText}>Fee</Text><Text style={styles.orderValue}>{money(t.fee)}</Text></View></Card>)}
        </>}
        <Text style={styles.footer}>QUANTBOT AI · PAPER TRADING LAB{"\n"}Virtual funds only · Demo market data</Text>
      </ScrollView>
    </KeyboardAvoidingView>
    <View style={styles.bottomNav}>
      {[["Home","⌂"],["Trade","↕"],["Portfolio","◫"],["History","◷"]].map(([name, glyph]) => <Pressable key={name} onPress={() => navigate(name)} style={styles.navItem}><Text style={[styles.navGlyph, tab === name && styles.navActive]}>{glyph}</Text><Text style={[styles.navText, tab === name && styles.navActive]}>{name}</Text></Pressable>)}
    </View>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:"#080b12",paddingTop:Platform.OS==="android"?StatusBar.currentHeight||0:0},
  topHeader:{height:65,paddingHorizontal:18,borderBottomWidth:1,borderBottomColor:"#202a38",flexDirection:"row",alignItems:"center",justifyContent:"space-between"},
  brandRow:{flexDirection:"row",alignItems:"center",gap:10},brandIcon:{width:36,height:36,borderRadius:11,backgroundColor:"#12342f",borderWidth:1,borderColor:"#22574d",alignItems:"center",justifyContent:"center"},brandGlyph:{fontSize:21,color:"#42e0bd",fontWeight:"900"},brand:{fontSize:15,fontWeight:"900",letterSpacing:1.1,color:"#edf2f9"},brandAccent:{color:"#39d6b1"},brandSub:{fontSize:8,letterSpacing:1.8,color:"#728096",marginTop:3,fontWeight:"700"},
  pill:{paddingHorizontal:9,paddingVertical:6,borderRadius:6,backgroundColor:"#10231f",borderWidth:1,borderColor:"#235248",alignSelf:"flex-start"},pillRed:{backgroundColor:"#301b23",borderColor:"#63313e"},pillAmber:{backgroundColor:"#30291a",borderColor:"#584827"},pillText:{fontSize:9,fontWeight:"800",letterSpacing:.5,color:"#55d9b7"},redText:{color:"#f07887"},amberText:{color:"#e7c071"},
  scrollContent:{padding:15,paddingBottom:25,gap:13},welcome:{paddingTop:7,paddingBottom:3},eyebrow:{fontSize:9,letterSpacing:1.4,fontWeight:"800",color:"#46c9ac",marginBottom:8},pageTitle:{fontSize:25,fontWeight:"800",letterSpacing:-.6,color:"#edf2f9"},subtitle:{fontSize:11,color:"#7f8ca0",marginTop:7,lineHeight:17},
  card:{backgroundColor:"#0e141e",borderWidth:1,borderColor:"#202a38",borderRadius:12,padding:15},equityCard:{padding:17,overflow:"hidden"},equityTop:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},mutedLabel:{fontSize:9,letterSpacing:1,fontWeight:"700",color:"#8290a4"},equityIcon:{width:30,height:30,borderRadius:8,backgroundColor:"#172a2a",alignItems:"center",justifyContent:"center"},equityValue:{fontSize:31,fontWeight:"800",letterSpacing:-1,color:"#f0f5fb",marginTop:10},equityBottom:{flexDirection:"row",gap:8,alignItems:"center",marginTop:6},greenText:{color:"#44d4ad",fontSize:11,fontWeight:"700"},dimText:{fontSize:10,color:"#7f8da1"},equityChart:{height:70,marginTop:8},chartCaption:{fontSize:9,color:"#6e7d91",marginTop:2},
  statGrid:{flexDirection:"row",gap:11},smallStat:{flex:1,padding:13},statValue:{fontSize:18,fontWeight:"800",color:"#edf2f9",marginTop:10,marginBottom:6,letterSpacing:-.4},
  sectionHead:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginBottom:13},sectionTitle:{fontSize:15,fontWeight:"750",color:"#edf2f9",marginTop:5},marketRow:{flexDirection:"row",alignItems:"center",paddingVertical:12,borderBottomWidth:1,borderBottomColor:"#202a38"},coin:{width:34,height:34,borderRadius:17,alignItems:"center",justifyContent:"center",marginRight:10},btc:{backgroundColor:"#3a2b1b"},eth:{backgroundColor:"#222f4b"},sol:{backgroundColor:"#24382f"},coinText:{fontSize:15,fontWeight:"800",color:"#f4b45c"},marketInfo:{flex:1},marketName:{fontSize:12,fontWeight:"700",color:"#e1e9f4"},marketPrice:{fontSize:11,fontWeight:"700",color:"#e1e9f4",textAlign:"right"},marketRight:{alignItems:"flex-end",gap:4},aiRow:{flexDirection:"row",alignItems:"center",gap:12,marginVertical:14},aiIcon:{width:43,height:43,borderRadius:12,backgroundColor:"#112522",borderWidth:1,borderColor:"#295b53",alignItems:"center",justifyContent:"center"},aiGlyph:{fontSize:23,color:"#48d7b5"},aiDescription:{fontSize:10,color:"#7d8a9d",lineHeight:16,marginTop:5},signalRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderTopWidth:1,borderTopColor:"#202a38",paddingTop:12,paddingBottom:2,marginTop:7}, 
  toggleRow:{flexDirection:"row",padding:4,borderRadius:8,backgroundColor:"#090e15",borderWidth:1,borderColor:"#263142",marginBottom:18},toggleButton:{flex:1,paddingVertical:11,alignItems:"center",borderRadius:6},toggleText:{fontSize:10,fontWeight:"800",color:"#7d8a9c"},buySelected:{backgroundColor:"#163b32"},sellSelected:{backgroundColor:"#3a2029"},buyText:{color:"#53e0b7"},sellText:{color:"#ff8b9a"},fieldLabel:{fontSize:10,color:"#9ba8b9",marginBottom:8,marginTop:14,fontWeight:"600"},assetChoices:{flexDirection:"row",gap:8},assetChoice:{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"center",paddingVertical:9,borderRadius:8,borderWidth:1,borderColor:"#263142",backgroundColor:"#0a1018"},assetChoiceSelected:{borderColor:"#3c9e88",backgroundColor:"#112522"},assetChoiceText:{fontSize:11,color:"#dbe5f1",fontWeight:"700"},quoteBox:{marginTop:16,marginBottom:4,padding:14,backgroundColor:"#0a1018",borderRadius:8,borderWidth:1,borderColor:"#202a38"},quoteValue:{fontSize:25,fontWeight:"800",color:"#edf2f9",marginVertical:6},input:{height:46,borderRadius:8,borderWidth:1,borderColor:"#2a3546",backgroundColor:"#0a1018",color:"#edf2f9",paddingHorizontal:12,fontSize:14},orderLine:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginTop:13},orderValue:{fontSize:11,fontWeight:"700",color:"#dce5f0"},primaryButton:{marginTop:19,minHeight:45,backgroundColor:"#35d6b0",borderRadius:8,alignItems:"center",justifyContent:"center",paddingHorizontal:12},sellPrimary:{backgroundColor:"#ef7183"},primaryButtonText:{fontSize:11,fontWeight:"900",color:"#071711",textAlign:"center"},notice:{fontSize:10,color:"#6de3c3",lineHeight:16,marginTop:12,padding:10,borderRadius:7,backgroundColor:"#112c25"},disclaimer:{fontSize:9,color:"#8290a4",marginTop:14,lineHeight:15},
  separator:{height:1,backgroundColor:"#202a38",marginVertical:14},empty:{alignItems:"center",paddingVertical:32},emptyIcon:{fontSize:35,color:"#8295ad",marginBottom:12},tradeHistoryCard:{marginBottom:10},historyTop:{flexDirection:"row",alignItems:"center",marginBottom:4},footer:{textAlign:"center",fontSize:8,letterSpacing:1,color:"#647287",lineHeight:17,marginTop:8,marginBottom:5},
  bottomNav:{height:65,borderTopWidth:1,borderTopColor:"#202a38",backgroundColor:"#0b1019",flexDirection:"row",justifyContent:"space-around",alignItems:"center",paddingBottom:Platform.OS==="android"?4:0},navItem:{flex:1,alignItems:"center",justifyContent:"center",gap:3},navGlyph:{fontSize:22,color:"#68768b"},navText:{fontSize:9,color:"#778499",fontWeight:"600"},navActive:{color:"#43d9b5"}
});

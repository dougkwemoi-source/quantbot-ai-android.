# QuantBot AI Android Starter

Android-first React Native + Expo paper-trading app. This ZIP is configured for an EAS cloud build that outputs an installable APK.

## What is included
- Android dashboard with Home, Trade, Portfolio, and History tabs
- Virtual portfolio and paper-order UI
- Demo BTC, ETH, and SOL quotes
- API connection settings
- EAS APK build profile

## Build an APK

You need a free Expo account and internet access. The APK is built by Expo's build service, so this project ZIP does not itself contain an APK.

1. Install Node.js on your computer.
2. Extract this ZIP and open a terminal in the extracted folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Install EAS CLI and sign in:

   ```bash
   npm install -g eas-cli
   eas login
   ```

5. Configure the project if prompted:

   ```bash
   eas build:configure
   ```

6. Build an Android APK:

   ```bash
   eas build -p android --profile preview
   ```

7. When the build finishes, Expo prints a download link. Open it on your Android phone and install the APK. If Android asks, allow installs from your browser or file manager.

## Connect the backend

Edit `API_BASE` near the top of `App.js`.

- Physical Android phone: use your computer's LAN IP, for example `http://192.168.1.25:8000`.
- Android emulator: use `http://10.0.2.2:8000`.

Start the original FastAPI backend with:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

Your phone and computer must be on the same Wi-Fi network for a local backend. The starter shows demo values while the API is offline. Trades are not saved until the backend is connected.

## Important
- This app uses virtual funds only. It does not place real exchange orders.
- Quotes and chart lines are illustrative demo data.
- The AI panel is a placeholder, not a validated prediction model.
- The local HTTP URL is for development only. Use HTTPS before exposing a backend publicly.
